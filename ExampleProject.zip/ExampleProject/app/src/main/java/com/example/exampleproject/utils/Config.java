package com.example.exampleproject.utils;

public class Config {
    public static final String BASEURL = "https://7002-114-125-216-109.ap.ngrok.io/";
//    public static final String BASEURL = "http://konsultasi.bisadong.id/index.php/";
}
